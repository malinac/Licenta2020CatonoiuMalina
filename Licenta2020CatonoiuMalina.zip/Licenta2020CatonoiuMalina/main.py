import lr
import knn
import svd
import svm
import pandas as pd
import preprocessing
import os
import json
path = './Discrete data'


def main():
    scores = {}
    for filename in os.listdir(path):
        data = pd.read_csv(path + '/' + filename)
        score_file = {}
        data_cf = preprocessing.preprocessing(data)
        data_cl = preprocessing.preprocessing(data, classification=True)
        scores_lr = lr.model_logistic(data_cl)
        scores_svm = svm.model_svm(data_cl)
        scores_knn = knn.model_knn(data_cf)
        scores_svd = svd.model_svd(data_cf)

        score_file['Logistic Regression'] = scores_lr
        score_file['Support Vector Machines'] = scores_svm
        score_file['K Nearest Neighbors'] = scores_knn
        score_file['Single Value Decomposition'] = scores_svd
        score_file['Logistic Regression Optimized'] = lr.optimised_logisticRegression(data_cl)
        score_file['Support Vector Machines Optimized'] = svm.optimised_logisticRegression(data_cl)
        score_file['Single Value Decomposition Optimized'] = svd.optimized_SVD(data_cf)
        score_file['K Nearest Neighbors Optimized'] = knn.optimized_KNN(data_cf)
        scores[filename] = score_file
    with open('data.json', 'w') as fp:
        json.dump(scores, fp)
    return scores


print(main())




