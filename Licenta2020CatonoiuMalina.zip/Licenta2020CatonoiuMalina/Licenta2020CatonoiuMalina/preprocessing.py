import pandas as pd
import numpy as np


def preprocessing(data, classification=False):

    if classification:
        data.fillna(data.mean(), inplace=True)
        return data
    else:
        columns = ['pacientId', 'attributeId', 'outcome']
        new_data = pd.DataFrame(columns=columns)
        d = data.index
        dict = {}
        j = 1
        for c in data.columns:
            dict[c] = j
            j += 1
        for i in d:
            for col in data.columns:
                s = [str(int(i + 1)), str(dict[col]), str(data.loc[data.index[i], col])]
                new_data.loc[len(new_data)] = s
        new_data.replace(["NaN", "nan", "NA"], np.nan, inplace=True)
        new_data = new_data.dropna(axis=0)

        return new_data
