from math import sqrt
from sklearn import preprocessing, svm
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import RepeatedKFold, GridSearchCV
from sklearn.metrics import mean_squared_error
import pandas as pd
import preprocessing as prep
n_folds = [3, 5, 7, 10]
NUM_TRIALS = 1
p_grid = {
    'C': [0.1, 1, 10, 100, 1000],
    'gamma': [1, 0.1, 0.01, 0.001, 0.0001],
    'kernel': ['rbf', 'linear', 'poly']
}


def model_svm(data):
    X = data.drop('Target', axis=1)
    y = data['Target']
    n_folds = [3, 5, 7, 10]
    scores = {}
    for i in n_folds:
        rkf = RepeatedKFold(n_splits=i, n_repeats=NUM_TRIALS)
        score_rmse = 0
        for train_index, test_index in rkf.split(X):
            X_train, X_test = X.iloc[train_index], X.iloc[test_index]
            y_train, y_test = y.iloc[train_index], y.iloc[test_index]
            clf = make_pipeline(preprocessing.StandardScaler(), svm.SVC(decision_function_shape='ovo'))
            clf.fit(X_train, y_train)
            y_pred = clf.predict(X_test)
            score_rmse += sqrt(mean_squared_error(y_test, y_pred))
        scores["RMSE of Baseline SVM for " + str(i) + " fold validation"] = score_rmse/(NUM_TRIALS*i)
    return scores


def svm_GridSearch(X, y):
    clf = GridSearchCV(estimator=svm.SVC(), param_grid=p_grid, refit=True, cv=5, scoring='neg_root_mean_squared_error')
    clf.fit(X, y)
    optimised_model = clf.best_estimator_
    print(clf.best_estimator_)
    return optimised_model


def optimised_logisticRegression(data):
    X = data.drop('Target', axis=1)
    y = data['Target']
    scores = {}
    scaler = preprocessing.StandardScaler()
    scaler.fit(X, y)
    model = svm_GridSearch(X,y)
    for i in n_folds:
        rkf = RepeatedKFold(n_splits=i, n_repeats=NUM_TRIALS)
        score_rmse = 0
        for train_index, test_index in rkf.split(X):
            X_train, X_test = X.iloc[train_index], X.iloc[test_index]
            y_train, y_test = y.iloc[train_index], y.iloc[test_index]
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            score_rmse += sqrt(mean_squared_error(y_test, y_pred))

        scores["RMSE of Optimized SVM for " + str(i) + " fold validation"] = score_rmse / (NUM_TRIALS * i)
    return scores

