from surprise import Dataset, KNNBasic
from surprise import Reader
from surprise.model_selection import cross_validate, GridSearchCV
import pandas as pd
from surprise.prediction_algorithms.matrix_factorization import SVD

import preprocessing as prep



n_folds = [3, 5, 7, 10]
NUM_TRIALS = 1
p_grid = {
    'n_epochs': [5, 6, 7, 8, 9, 10],
    'lr_all': [0.002, 0.003, 0.004, 0.005],
    'reg_all': [0.4, 0.5, 0.6]
}


def model_svd(data):
    data['outcome'] = pd.to_numeric(data.outcome)
    min_rating = data.outcome.min()
    max_rating = data.outcome.max()
    scores = {}

    reader = Reader(rating_scale=(min_rating, max_rating))
    dataset = Dataset.load_from_df(data[['pacientId', 'attributeId', 'outcome']], reader)

    model = SVD()
    for i in n_folds:
        mean_rmse = 0
        for l in range(NUM_TRIALS):
            dict = cross_validate(model, dataset, measures=['RMSE'], cv=i)
            mean_rmse += dict['test_rmse'].mean()
        scores["RMSE of SVD for " + str(i) + " fold validation"] = mean_rmse/NUM_TRIALS
    return scores


def knn_GridSearch(data):

    clf = GridSearchCV(SVD, param_grid=p_grid, refit=True, cv=5)
    clf.fit(data)
    optimised_model = clf.best_estimator['rmse']
    print(clf.best_params)
    return optimised_model


def optimized_SVD(data):
    data['outcome'] = pd.to_numeric(data.outcome)
    min_rating = data.outcome.min()
    max_rating = data.outcome.max()
    scores = {}
    reader = Reader(rating_scale=(min_rating, max_rating))
    dataset = Dataset.load_from_df(data[['pacientId', 'attributeId', 'outcome']], reader)

    model = knn_GridSearch(dataset)
    for i in n_folds:
        mean_rmse = 0
        for l in range(NUM_TRIALS):
            dict = cross_validate(model, dataset, measures=['RMSE'], cv=i, verbose=False)
            mean_rmse += dict['test_rmse'].mean()
        scores["RMSE of KNN for " + str(i) + " fold validation"] = mean_rmse / NUM_TRIALS

    return scores

