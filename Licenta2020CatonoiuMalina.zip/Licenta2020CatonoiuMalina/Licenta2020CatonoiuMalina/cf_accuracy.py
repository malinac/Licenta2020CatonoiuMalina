from collections import defaultdict
from six import iteritems


def cf_accuracy(predictions, threshold=0.5):
    if not predictions:
        raise ValueError('Prediction list is empty.')

    predictions_u = defaultdict(list)
    n_correct = 0
    n_total = 0

    for u0, _, r0, est, _ in predictions:
        predictions_u[u0].append((r0, est))

    for u0, preds in iteritems(predictions_u):
        for r0i, esti in preds:
            n_total += 1
            if abs(r0i - esti) <threshold:
                n_correct +=1

    return n_correct/n_total