from surprise import Dataset, KNNBasic
from surprise import Reader
from surprise.model_selection import cross_validate, GridSearchCV
import pandas as pd
import preprocessing

n_folds = [3, 5, 7, 10]
NUM_TRIALS = 1
p_grid = {
    'k': [30, 40, 50, 60, 100],
    'sim_options': {'name': ['cosine', 'pearson_baseline'],
                              'user_based': [True]}
}


def model_knn(data):
    data['outcome'] = pd.to_numeric(data.outcome)
    min_rating = data.outcome.min()
    max_rating = data.outcome.max()
    scores = {}
    reader = Reader(rating_scale=(min_rating, max_rating))
    dataset = Dataset.load_from_df(data[['pacientId', 'attributeId', 'outcome']], reader)

    sim_options = {
        'name': 'cosine',
        'user_based': [True]
    }

    model = KNNBasic(sim_options=sim_options)
    for i in n_folds:
        mean_rmse = 0
        for l in range(NUM_TRIALS):
            dict = cross_validate(model, dataset, measures=['RMSE'], cv=i, verbose=False)
            mean_rmse += dict['test_rmse'].mean()
        scores["RMSE of KNN for " + str(i) + " fold validation"] = mean_rmse/NUM_TRIALS

    return scores


def knn_GridSearch(data):

    clf = GridSearchCV(KNNBasic, param_grid=p_grid, refit=True, cv=5)
    clf.fit(data)
    optimised_model = clf.best_estimator['rmse']
    print(clf.best_params)
    return optimised_model

def optimized_KNN(data):
    data['outcome'] = pd.to_numeric(data.outcome)
    min_rating = data.outcome.min()
    max_rating = data.outcome.max()
    scores = {}
    reader = Reader(rating_scale=(min_rating, max_rating))
    dataset = Dataset.load_from_df(data[['pacientId', 'attributeId', 'outcome']], reader)

    model = knn_GridSearch(dataset)
    for i in n_folds:
        mean_rmse = 0
        for l in range(NUM_TRIALS):
            dict = cross_validate(model, dataset, measures=['RMSE'], cv=i, verbose=False)
            mean_rmse += dict['test_rmse'].mean()
        scores["RMSE of KNN for " + str(i) + " fold validation"] = mean_rmse / NUM_TRIALS

    return scores



