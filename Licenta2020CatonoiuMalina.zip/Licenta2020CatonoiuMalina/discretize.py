import pandas as pd

# Discretising the continuous values from the Chronic Kidney Disease dataset in 5 bins

df1 = pd.read_csv('Raw data/chronic_kidney_disease.csv')
df1['age'] = pd.cut(df1['age'], bins=5, labels=[1, 2, 3, 4, 5])
df1['bp'] = pd.cut(df1['bp'], bins=5, labels=[1, 2, 3, 4, 5])
df1['bgr'] = pd.cut(df1['bgr'], bins=5, labels=[1, 2, 3, 4, 5])
df1['bu'] = pd.cut(df1['bu'], bins=5, labels=[1, 2, 3, 4, 5])
df1['sc'] = pd.cut(df1['sc'], bins=5, labels=[1, 2, 3, 4, 5])
df1['sod'] = pd.cut(df1['sod'], bins=5, labels=[1, 2, 3, 4, 5])
df1['pot'] = pd.cut(df1['pot'], bins=5, labels=[1, 2, 3, 4, 5])
df1['hemo'] = pd.cut(df1['hemo'], bins=5, labels=[1, 2, 3, 4, 5])
df1['pcv'] = pd.cut(df1['pcv'], bins=5, labels=[1, 2, 3, 4, 5])
df1['wbcc'] = pd.cut(df1['wbcc'], bins=5, labels=[1, 2, 3, 4, 5])
df1['rbcc'] = pd.cut(df1['rbcc'], bins=5, labels=[1, 2, 3, 4, 5])
df1.replace([1.005, 1.010, 1.015, 1.020, 1.025], [1, 2, 3, 4, 5], inplace=True)
df1 = df1.sample(frac=1)
df1.to_csv('Discrete data/chronic_kidney_disease_discrete.csv', index=None)

# Discretizing the continuous values from the dermatology dataset in 4 bins
df2 = pd.read_csv('Raw data/dermatology.csv')
df2['age'] = pd.cut(df2['age'], bins=4, labels=[1, 2, 3, 4])
df2.to_csv('Discrete data/dermatology_discrete.csv', index=None)

# Discretizing the continuous values from the HCV dataset in 4 bins
df3 = pd.read_csv('Raw data/HCV-Egy-Data.csv')
df3['Age'] = pd.cut(df3['Age'], bins=4, labels=[1, 2, 3, 4])
df3['BMI'] = pd.cut(df3['BMI'], bins=4, labels=[1, 2, 3, 4])
df3['WBC'] = pd.cut(df3['WBC'], bins=4, labels=[1, 2, 3, 4])
df3['RBC'] = pd.cut(df3['RBC'], bins=4, labels=[1, 2, 3, 4])
df3['HGB'] = pd.cut(df3['HGB'], bins=4, labels=[1, 2, 3, 4])
df3['AST 1'] = pd.cut(df3['AST 1'], bins=4, labels=[1, 2, 3, 4])
df3['ALT 1'] = pd.cut(df3['ALT 1'], bins=4, labels=[1, 2, 3, 4])
df3['ALT4'] = pd.cut(df3['ALT4'], bins=4, labels=[1, 2, 3, 4])
df3['ALT 12'] = pd.cut(df3['ALT 12'], bins=4, labels=[1, 2, 3, 4])
df3['ALT 24'] = pd.cut(df3['ALT 24'], bins=4, labels=[1, 2, 3, 4])
df3['ALT 36'] = pd.cut(df3['ALT 36'], bins=4, labels=[1, 2, 3, 4])
df3['ALT 48'] = pd.cut(df3['ALT 48'], bins=4, labels=[1, 2, 3, 4])
df3['RNA Base'] = pd.cut(df3['RNA Base'], bins=4, labels=[1, 2, 3, 4])
df3['RNA 4'] = pd.cut(df3['RNA 4'], bins=4, labels=[1, 2, 3, 4])
df3['RNA 12'] = pd.cut(df3['RNA 12'], bins=4, labels=[1, 2, 3, 4])
df3['Plat'] = pd.cut(df3['Plat'], bins=4, labels=[1, 2, 3, 4])
df3['ALT after 24 w'] = pd.cut(df3['ALT after 24 w'], bins=4, labels=[1, 2, 3, 4])
df3['RNA EOT'] = pd.cut(df3['RNA EOT'], bins=4, labels=[1, 2, 3, 4])
df3['RNA EF'] = pd.cut(df3['RNA EF'], bins=4, labels=[1, 2, 3, 4])
df3['Baseline histological Grading'] = pd.cut(df3['Baseline histological Grading'], bins=4, labels=[1, 2, 3, 4])
df3.to_csv('Discrete data/HCV_discrete.csv', index=None)

# Discretizing the continuous values from the Cleveland dataset in 4 bins
df4 = pd.read_csv('Raw data/cleveland.csv')
df4.loc[df4.Class >= 1, 'Class'] = 1
df4.loc[df4.Thal == 3, 'Thal'] = 1
df4.loc[df4.Thal == 6, 'Thal'] = 2
df4.loc[df4.Thal == 7, 'Thal'] = 3
df4['Age'] = pd.cut(df4['Age'], bins=4, labels=[1, 2, 3, 4])
df4['TrestBps'] = pd.cut(df4['TrestBps'], bins=4, labels=[1, 2, 3, 4])
df4['Chol'] = pd.cut(df4['Chol'], bins=4, labels=[1, 2, 3, 4])
df4['Thalach'] = pd.cut(df4['Thalach'], bins=4, labels=[1, 2, 3, 4])
df4['Oldpeak'] = pd.cut(df4['Oldpeak'], bins=4, labels=[1, 2, 3, 4])
df4.to_csv('Discrete data/cleveland_discrete.csv', index=None)

